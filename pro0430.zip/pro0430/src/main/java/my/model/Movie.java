package my.model;

import java.util.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;

public class Movie {
	private int movieId;
	private String title;
	private String maker;
	private int price;
	private Date openDate;
	private String poster;
	private String after; 
	
	public Movie() {} //기본생성자

	public Movie(String title, String maker, int price, Date openDate, String poster) {
		super();
		this.title = title;
		this.maker = maker;
		this.price = price;
		this.openDate = openDate;
		this.poster = poster;
	}
	
	public String getAfter() {
		return after;
	}

	public void setAfter(String after) {
		this.after = after;
	}

	public int getMovieId() {
		return movieId;
	}

	public void setMovieId(int movieId) {
		this.movieId = movieId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getMaker() {
		return maker;
	}

	public void setMaker(String maker) {
		this.maker = maker;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public Date getOpenDate() {
		return openDate;
	}

	public void setOpenDate(Date openDate) {
		this.openDate = openDate;
	} 
	
	public void setOpenDate(String openDate) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		try {
			this.openDate = new java.util.Date(sdf.parse(openDate).getTime());
		} catch (ParseException e) {
		}
	}

	public String getPoster() {
		return poster;
	}

	public void setPoster(String poster) {
		this.poster = poster;
	}
	
	

}
