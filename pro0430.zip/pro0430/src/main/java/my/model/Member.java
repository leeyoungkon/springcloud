package my.model;

public class Member {
	private String memberId;
	private String password;
	private String name;
	private String email; 
	private String[] hobby;
	private String[] subMajor;
	
	public Member() {}

	public Member(String memberId, String password, String name, String email, String[] hobby, String[] subMajor) {
		super();
		this.memberId = memberId;
		this.password = password;
		this.name = name;
		this.email = email;
		this.hobby = hobby;
		this.subMajor = subMajor;
	}
	
	

	public String[] getHobby() {
		return hobby;
	}

	public void setHobby(String[] hobby) {
		this.hobby = hobby;
	}

	public String[] getSubMajor() {
		return subMajor;
	}

	public void setSubMajor(String[] subMajor) {
		this.subMajor = subMajor;
	}

	public String getMemberId() {
		return memberId;
	}

	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
	
	

}
